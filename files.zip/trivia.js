const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const { addPoints } = require("../utils/points");

function decodeHtml(str) {
  return str
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/&eacute;/g, "é")
    .replace(/&uuml;/g, "ü")
    .replace(/&ouml;/g, "ö")
    .replace(/&auml;/g, "ä")
    .replace(/&rsquo;/g, "'")
    .replace(/&ldquo;/g, "\u201c")
    .replace(/&rdquo;/g, "\u201d");
}

function shuffle(array) {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("trivia")
    .setDescription("Answer a random trivia question."),

  async execute(interaction) {
    await interaction.deferReply();

    let question;
    try {
      const response = await fetch(
        "https://opentdb.com/api.php?amount=1&type=multiple"
      );
      const data = await response.json();
      question = data.results?.[0];
    } catch (err) {
      await interaction.editReply(
        "Couldn't reach the trivia API right now. Try again in a bit."
      );
      return;
    }

    if (!question) {
      await interaction.editReply("Couldn't fetch a trivia question. Try again.");
      return;
    }

    const correctAnswer = decodeHtml(question.correct_answer);
    const allAnswers = shuffle([
      correctAnswer,
      ...question.incorrect_answers.map(decodeHtml),
    ]);

    const row = new ActionRowBuilder().addComponents(
      allAnswers.map((answer, index) =>
        new ButtonBuilder()
          .setCustomId(`trivia_${index}`)
          .setLabel(answer.slice(0, 80)) // Discord button label limit
          .setStyle(ButtonStyle.Secondary)
      )
    );

    const message = await interaction.editReply({
      content: `🧠 **${decodeHtml(question.category)}** (${question.difficulty})\n${decodeHtml(
        question.question
      )}`,
      components: [row],
    });

    const collector = message.createMessageComponentCollector({
      time: 20_000,
      filter: (i) => i.user.id === interaction.user.id,
    });

    collector.on("collect", async (buttonInteraction) => {
      const chosenIndex = parseInt(
        buttonInteraction.customId.replace("trivia_", ""),
        10
      );
      const chosenAnswer = allAnswers[chosenIndex];
      const isCorrect = chosenAnswer === correctAnswer;

      let resultText;
      if (isCorrect) {
        const points = question.difficulty === "hard" ? 20 : question.difficulty === "medium" ? 15 : 10;
        const total = addPoints(
          interaction.user.id,
          interaction.user.username,
          points
        );
        resultText = `✅ Correct! **+${points} points** (total: ${total})`;
      } else {
        resultText = `❌ Wrong — the correct answer was **${correctAnswer}**.`;
      }

      await buttonInteraction.update({
        content: `${message.content}\n\n${resultText}`,
        components: [],
      });

      collector.stop();
    });

    collector.on("end", (collected) => {
      if (collected.size === 0) {
        interaction.editReply({
          content: `${message.content}\n\n⌛ Time's up! The correct answer was **${correctAnswer}**.`,
          components: [],
        });
      }
    });
  },
};
