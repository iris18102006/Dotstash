const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { getTopPlayers, getUserPoints } = require("../utils/points");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("leaderboard")
    .setDescription("Show the top players by points."),

  async execute(interaction) {
    const top = getTopPlayers(10);

    if (top.length === 0) {
      await interaction.reply(
        "No points on the board yet — go play some games!"
      );
      return;
    }

    const medals = ["🥇", "🥈", "🥉"];
    const lines = top.map((player, index) => {
      const rank = medals[index] || `${index + 1}.`;
      return `${rank} **${player.username}** — ${player.points} pts`;
    });

    const userPoints = getUserPoints(interaction.user.id);

    const embed = new EmbedBuilder()
      .setTitle("🏆 Leaderboard")
      .setDescription(lines.join("\n"))
      .setFooter({ text: `Your points: ${userPoints}` })
      .setColor(0x5865f2);

    await interaction.reply({ embeds: [embed] });
  },
};
