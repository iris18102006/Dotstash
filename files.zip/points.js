const fs = require("fs");
const path = require("path");

const DATA_PATH = path.join(__dirname, "..", "data", "scores.json");

// Make sure the data file exists so the bot doesn't crash on first run
function ensureDataFile() {
  if (!fs.existsSync(DATA_PATH)) {
    fs.mkdirSync(path.dirname(DATA_PATH), { recursive: true });
    fs.writeFileSync(DATA_PATH, JSON.stringify({}, null, 2));
  }
}

function loadScores() {
  ensureDataFile();
  const raw = fs.readFileSync(DATA_PATH, "utf-8");
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function saveScores(scores) {
  fs.writeFileSync(DATA_PATH, JSON.stringify(scores, null, 2));
}

// Add points to a user (creates entry if it doesn't exist yet)
function addPoints(userId, username, amount) {
  const scores = loadScores();

  if (!scores[userId]) {
    scores[userId] = { username, points: 0 };
  }

  // keep username fresh in case they change their display name
  scores[userId].username = username;
  scores[userId].points += amount;

  saveScores(scores);
  return scores[userId].points;
}

function getTopPlayers(limit = 10) {
  const scores = loadScores();
  return Object.values(scores)
    .sort((a, b) => b.points - a.points)
    .slice(0, limit);
}

function getUserPoints(userId) {
  const scores = loadScores();
  return scores[userId]?.points ?? 0;
}

module.exports = {
  addPoints,
  getTopPlayers,
  getUserPoints,
};
