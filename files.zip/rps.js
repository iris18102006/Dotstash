const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const { addPoints } = require("../utils/points");

const CHOICES = ["rock", "paper", "scissors"];
const EMOJI = { rock: "🪨", paper: "📄", scissors: "✂️" };

function decideWinner(player, bot) {
  if (player === bot) return "tie";

  const beats = {
    rock: "scissors",
    paper: "rock",
    scissors: "paper",
  };

  return beats[player] === bot ? "win" : "lose";
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("rps")
    .setDescription("Play rock paper scissors against the bot."),

  async execute(interaction) {
    const row = new ActionRowBuilder().addComponents(
      CHOICES.map((choice) =>
        new ButtonBuilder()
          .setCustomId(`rps_${choice}`)
          .setLabel(choice[0].toUpperCase() + choice.slice(1))
          .setEmoji(EMOJI[choice])
          .setStyle(ButtonStyle.Primary)
      )
    );

    const message = await interaction.reply({
      content: "Choose your move:",
      components: [row],
      fetchReply: true,
    });

    const collector = message.createMessageComponentCollector({
      time: 15_000,
      filter: (i) => i.user.id === interaction.user.id,
    });

    collector.on("collect", async (buttonInteraction) => {
      const playerChoice = buttonInteraction.customId.replace("rps_", "");
      const botChoice = CHOICES[Math.floor(Math.random() * CHOICES.length)];
      const outcome = decideWinner(playerChoice, botChoice);

      let resultText;
      if (outcome === "tie") {
        resultText = "It's a tie!";
      } else if (outcome === "win") {
        const total = addPoints(
          interaction.user.id,
          interaction.user.username,
          10
        );
        resultText = `You win! **+10 points** (total: ${total})`;
      } else {
        resultText = "You lose! Better luck next time.";
      }

      await buttonInteraction.update({
        content: `You picked ${EMOJI[playerChoice]} **${playerChoice}**, bot picked ${EMOJI[botChoice]} **${botChoice}**.\n${resultText}`,
        components: [],
      });

      collector.stop();
    });

    collector.on("end", async (collected) => {
      if (collected.size === 0) {
        await interaction.editReply({
          content: "No move chosen in time — game cancelled.",
          components: [],
        });
      }
    });
  },
};
