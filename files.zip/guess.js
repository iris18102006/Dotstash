const { SlashCommandBuilder } = require("discord.js");
const { addPoints } = require("../utils/points");

const MAX_NUMBER = 100;
const MAX_ATTEMPTS = 7;
const TIME_LIMIT_MS = 60_000;

module.exports = {
  data: new SlashCommandBuilder()
    .setName("guess")
    .setDescription(
      `Guess a number between 1 and ${MAX_NUMBER}. You get ${MAX_ATTEMPTS} tries.`
    ),

  async execute(interaction) {
    const target = Math.floor(Math.random() * MAX_NUMBER) + 1;
    let attemptsLeft = MAX_ATTEMPTS;

    await interaction.reply(
      `🎯 I'm thinking of a number between 1 and ${MAX_NUMBER}. You have ${MAX_ATTEMPTS} guesses — just type a number in the chat!`
    );

    const channel = interaction.channel;

    const collector = channel.createMessageCollector({
      filter: (msg) =>
        msg.author.id === interaction.user.id && /^\d+$/.test(msg.content.trim()),
      time: TIME_LIMIT_MS,
    });

    collector.on("collect", async (msg) => {
      const guess = parseInt(msg.content.trim(), 10);
      attemptsLeft--;

      if (guess === target) {
        const attemptsUsed = MAX_ATTEMPTS - attemptsLeft;
        // Fewer attempts used = more points. Fastest guess = 25, slowest = 10.
        const pointsAwarded = Math.max(10, 25 - (attemptsUsed - 1) * 2);
        const total = addPoints(
          interaction.user.id,
          interaction.user.username,
          pointsAwarded
        );
        await msg.reply(
          `🎉 Correct! The number was **${target}**. **+${pointsAwarded} points** (total: ${total})`
        );
        collector.stop("won");
        return;
      }

      if (attemptsLeft <= 0) {
        await msg.reply(
          `💀 Out of guesses! The number was **${target}**. Better luck next time.`
        );
        collector.stop("lost");
        return;
      }

      const hint = guess < target ? "higher ⬆️" : "lower ⬇️";
      await msg.reply(`Not quite — try **${hint}**. (${attemptsLeft} guesses left)`);
    });

    collector.on("end", (collected, reason) => {
      if (reason !== "won" && reason !== "lost") {
        interaction.followUp(
          `⌛ Time's up! The number was **${target}**.`
        );
      }
    });
  },
};
