# FriendBot 🎮

A fun Discord bot with mini-games for you and your friends — trivia, rock
paper scissors, number guessing, magic 8-ball, coinflip, and a persistent
points leaderboard.

## Commands

| Command | What it does |
|---|---|
| `/trivia` | Random trivia question with multiple-choice buttons. Points scale with difficulty. |
| `/rps` | Rock paper scissors vs. the bot, button-based. |
| `/guess` | Bot picks 1–100, you get 7 guesses typed in chat, with higher/lower hints. |
| `/8ball <question>` | Ask the magic 8-ball anything. |
| `/coinflip` | Heads or tails. |
| `/leaderboard` | Shows top 10 players by points earned across all games. |

Points persist locally in `data/scores.json` — nobody loses their progress
when the bot restarts.

## Setup

### 1. Create a Discord application

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications)
2. Click **New Application**, name it whatever you want
3. Go to the **Bot** tab → click **Reset Token** → copy the token
   (this is your `DISCORD_TOKEN` — keep it secret, never commit it)
4. Under **Privileged Gateway Intents**, enable **Message Content Intent**
   (needed for `/guess` to read your number guesses in chat)
5. Go to **OAuth2 → URL Generator**:
   - Scopes: `bot`, `applications.commands`
   - Bot Permissions: `Send Messages`, `Read Message History`, `Use Slash Commands`
   - Copy the generated URL and open it to invite the bot to your server

### 2. Get your IDs

- **CLIENT_ID**: found on the **General Information** tab of your application
- **GUILD_ID**: right-click your Discord server icon → Copy Server ID
  (you need Developer Mode enabled in Discord: User Settings → Advanced → Developer Mode)

### 3. Configure environment variables

```bash
cp .env.example .env
```

Fill in `.env` with your actual token, client ID, and guild ID.

### 4. Install and run

```bash
npm install
npm run deploy   # registers the slash commands to your server
npm start        # starts the bot
```

Your commands show up instantly since they're registered per-server (guild
commands). If you ever want the bot in multiple servers with global
commands, swap `Routes.applicationGuildCommands` for
`Routes.applicationCommands` in `deploy-commands.js` — just know global
commands take up to an hour to propagate.

## Project structure

```
friendbot/
├── commands/
│   ├── 8ball.js
│   ├── coinflip.js
│   ├── guess.js
│   ├── leaderboard.js
│   ├── rps.js
│   └── trivia.js
├── utils/
│   └── points.js        # JSON-based points persistence
├── data/
│   └── scores.json       # created automatically on first run
├── deploy-commands.js     # registers slash commands with Discord
├── index.js                # bot entry point
├── .env.example
└── package.json
```

## Adding a new game

1. Create a new file in `commands/`
2. Export `data` (a `SlashCommandBuilder`) and an async `execute(interaction)` function
3. Run `npm run deploy` again to register it — the bot auto-loads any file in `commands/`

## Notes

- Trivia questions come from the free [Open Trivia Database](https://opentdb.com/) —
  no API key needed.
- `data/scores.json` is gitignored since it's local save data specific to
  your server, not something you'd want to publish or overwrite via git.
